package com.capgemini.main;

import java.math.BigDecimal;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.exception.DupicateMobileNumberException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.MobilenumberIsNotFoundException;
import com.capgemini.repo.WalletRepoInterface;
import com.capgemini.repo.WalletRepositoryImp;
import com.capgemini.service.WalletService;
import com.capgemini.service.WalletServiceImp;

public class MobileWallet {

	static Scanner sc = new Scanner(System.in);
	static WalletRepoInterface walletRepo = new WalletRepositoryImp();
	static WalletService walletService = new WalletServiceImp(walletRepo);
	
	public static void main(String[] args) throws InsufficientBalanceException, DupicateMobileNumberException, MobilenumberIsNotFoundException {
		
		while(true)
		{
			
			System.out.println("1). create new account");
			System.out.println("2). show balance");
			System.out.println("3). Deposit balance");
			System.out.println("4). WithDraw balance");
			System.out.println("5). Fund transfer");
			System.out.println("6). Exit");
			System.out.println("***********************************************************************************************************");
			System.out.println("Enter your Choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: createAccount();break;
			case 2: showBalance();break;
			case 3:	deposit();break; 
			case 4: withDraw();break;
			case 5: fundTransfer();break;
			case 6: System.exit(0);
			default:System.out.println("Wrong Choice!!");break;
			}
		}

	}

	private static void fundTransfer() {
		
		System.out.println("Enter Source Mobile Number");
		sc.nextLine();
		String sourceMobileNo = sc.nextLine();
		while (!validateMobileNo(sourceMobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			sourceMobileNo = sc.nextLine();
		}
		
		System.out.println("Enter Target Mobile Number"); 
		String targetMobileNo = sc.nextLine();
		while (!validateMobileNo(targetMobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			targetMobileNo = sc.nextLine();
		}
		
		System.out.println("Enter Amount");
		BigDecimal balance = sc.nextBigDecimal();
		while (!validateBalance(balance)) {
			System.out.println("balance is invalid :: Try again(balance must be positive)");
			balance = sc.nextBigDecimal();
		}
		
		try {
			Customer customer = walletService.fundTransfer(sourceMobileNo, targetMobileNo, balance);
			System.out.println("Amount Transferred Successfully");
			System.out.println("Hello!! Target Customer Name is: " + customer.getName() + " And Upadted balance is : " + customer.getWallet().getBalance());
			System.out.println("*************************************************************************************************************************");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void withDraw() {
		
		System.out.println("Enter Mobile Number");
		sc.nextLine();
		String mobileNo = sc.nextLine();
		while (!validateMobileNo(mobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			mobileNo = sc.nextLine();
		}
		
		System.out.println("Enter Amount");
		BigDecimal balance = sc.nextBigDecimal();
		while (!validateBalance(balance)) {
			System.out.println("balance is invalid :: Try again(balance must be positive)");
			balance = sc.nextBigDecimal();
		}
		
		try {
			Customer customer = walletService.withDrawAmount(mobileNo, balance);
			System.out.println("Amount WithDraw Successfully");
			System.out.println("Hello "+customer.getName() + " Your updated balance is "+customer.getWallet().getBalance());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void deposit() {
		
		System.out.println("Enter Mobile Number");
		sc.nextLine();
		String mobileNo = sc.nextLine();
		while (!validateMobileNo(mobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			mobileNo = sc.nextLine();
		}
		
		System.out.println("Enter Amount");
		BigDecimal balance = sc.nextBigDecimal();
		while (!validateBalance(balance)) {
			System.out.println("balance is invalid :: Try again(balance must be positive)");
			balance = sc.nextBigDecimal();
		}
		
		try {
			Customer customer = walletService.depositAmount(mobileNo, balance);
			System.out.println("Amount Deposited Successfully");
			System.out.println("Hello "+customer.getName() + " Your updated balance is "+customer.getWallet().getBalance());
		} catch (MobilenumberIsNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void showBalance() {
		System.out.println("Enter Mobile Number");
		sc.nextLine();
		String mobileNo = sc.nextLine();
		while (!validateMobileNo(mobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			mobileNo = sc.nextLine();
		}
		try {
			Customer customer = walletService.showBalance(mobileNo);
			System.out.println("Hello "+customer.getName()+" Your Balance is " + customer.getWallet().getBalance());
			System.out.println("***********************************************************************************************************");
		} catch (MobilenumberIsNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	private static void createAccount() {
		System.out.println("Enter user name");
		sc.nextLine();
		
		String name = sc.nextLine();
		while (!validateName(name)) {
			System.out.println("User name is invalid :: Try again(User name must not have numbers)");
			name = sc.nextLine();
		}
		
		System.out.println("Enter mobile number");
		String mobileNo = sc.nextLine();
		while (!validateMobileNo(mobileNo)) {
			System.out.println("Mobile number invalid :: Try again(Mobile number must  starting with 6,7,8,9 and have a length of 10)");
			mobileNo = sc.nextLine();
		}
		
		System.out.println("Enter Balance");
		BigDecimal balance = sc.nextBigDecimal();
		while (!validateBalance(balance)) {
			System.out.println("balance is invalid :: Try again(balance must be positive)");
			balance = sc.nextBigDecimal();
		}
		try {
			Customer customer = walletService.createAccount(name, mobileNo, new Wallet(balance));
			System.out.println("New Customer Added Suceesfully!!");
			System.out.println("_____________________________________");
			System.out.println("Infomation Is:");
			System.out.println("*****************************************");
			System.out.println("name is: " + customer.getName());
			System.out.println("Mobile number is: " + customer.getMobileNo());
			System.out.println("Balance is: " + customer.getWallet().getBalance());
			System.out.println("**********************************************************************");
		}catch(Exception e) {System.out.println(e.getMessage());}
		
	}

	private static boolean validateBalance(BigDecimal balance) {
		if(balance.intValue() <= 0 )
			return false;
		else
			return true;
	}

	private static boolean validateMobileNo(String mobileNo) {
		Pattern pattern = Pattern.compile("[6789]{1}[0-9]{9}");
		Matcher m = pattern.matcher(mobileNo);
		if(m.matches())
			return true;
		else
			return false;
	}

	private static boolean validateName(String name) {
		Pattern pattern = Pattern.compile("[a-zA-Z]+");
		Matcher m = pattern.matcher(name);
		if(m.matches())
			return true;
		else
			return false;
	}

}
