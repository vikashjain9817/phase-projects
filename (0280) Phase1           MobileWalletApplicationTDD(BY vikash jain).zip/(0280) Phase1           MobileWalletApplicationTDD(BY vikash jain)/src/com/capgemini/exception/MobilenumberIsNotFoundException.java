package com.capgemini.exception;

public class MobilenumberIsNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MobilenumberIsNotFoundException(String msg) {
		super(msg);
	}

}
