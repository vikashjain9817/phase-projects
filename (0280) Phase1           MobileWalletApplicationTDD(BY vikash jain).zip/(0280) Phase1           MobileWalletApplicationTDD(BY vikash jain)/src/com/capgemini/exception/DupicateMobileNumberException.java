package com.capgemini.exception;

public class DupicateMobileNumberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DupicateMobileNumberException(String msg)
	{
		super(msg);
	}
	

}
